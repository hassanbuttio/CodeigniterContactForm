<!DOCTYPE html>
<html lang="en">
<head>
  <title>Contact Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Contact form</h2>
  <form action="<?php base_url() ?>index.php/MainController/ContactInsert" method="POST">

<!-- <?php echo validation_errors(); ?>
 -->    <div class="form-group">
      <label for="fullname">Fullname:</label>
      <input type="text" class="form-control" id="fullname" placeholder="Enter Fullname" name="fullname">
    </div>
    <?php echo form_error('fullname'); ?>
        <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
        <?php echo form_error('email'); ?>

        <div class="form-group">
      <label for="subject">subject:</label>
      <input type="text" class="form-control" id="subject" placeholder="Enter subject" name="subject">
    </div>

    <div class="form-group">
      <label for="message">Message:</label>
      <input type="text" class="form-control" id="message" placeholder="Enter Message" name="message">
    </div>
            <?php echo form_error('message'); ?>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>

</body>
</html>
