<?php
class mainModel extends CI_Model{
	function insertContactData($contactData){
   $this->load->database();
   $this->db->insert('tbl_users',$contactData);
   	}
}


?>