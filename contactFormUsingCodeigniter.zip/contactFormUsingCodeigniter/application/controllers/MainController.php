<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MainController extends CI_Controller {


	public function index()
	{
		$this->load->view('index');
	}

		public function contactInsert()
	{
        $this->load->library('form_validation');
        $this->form_validation->set_rules('fullname','Full Name','required|alpha');
        $this->form_validation->set_rules('email','Email','required');
       $this->form_validation->set_rules('message','Message','required|alpha');
if($this->form_validation->run()){
            $this->load->model('mainModel');
		$userData = array(
    'userFullname' => $this->input->post('fullname'),
    'userEmail' => $this->input->post('email'),
    'userSubject' => $this->input->post('subject'),
	'userMessage	' => $this->input->post('message'));
$this->mainModel->insertContactData($userData);
return $this->load->view('success');	
            }

            else{
            	$this->index();
            }
		


	}
}
